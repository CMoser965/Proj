import torch 
import numpy as np
from torchvision import datasets
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
from torchsummary import summary
import pickle
import matplotlib.pyplot as plt

num_workers = 0
batch_size = 30

transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Lambda(lambda x: torch.nn.functional.avg_pool2d(x, kernel_size=4, stride=2)),
])

train_data = datasets.MNIST(root='data', train=True,
                            download=True, transform=transform)
test_data = datasets.MNIST(root='data', train=False,
                            download=True, transform=transform)

train_loader = torch.utils.data.DataLoader(train_data, batch_size=batch_size, num_workers=num_workers)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, num_workers=num_workers)

class NeuralNet(nn.Module):
  def __init__(self):
    super(NeuralNet, self).__init__()
    
    # linear input layer
    self.inputLayer = nn.Linear(13 * 13, 169)
    # First hidden layer
    self.hl1 = nn.Linear(169, 16)
    # second hidden layer
    self.hl2 = nn.Linear(16, 10)

  def forward(self, x):
    x = x.view(x.size(0), -1)
    x = F.tanh(self.inputLayer(x))
    x = F.tanh(self.hl1(x))
    x = self.hl2(x)
    return x

  def exportBiases(self):
    with open("biases.dat", "w") as writefile:
      writefile.write("Input bias\n")
      for layer in self.inputLayer.bias.data:
        writefile.write(str(layer.item()) + ",")
      writefile.write("\nFirst Hidden\n")
      for layer in self.hl1.bias.data:
        writefile.write(str(layer.item()) + ",")
      writefile.write("\nSecond Hidden\n")
      for layer in self.hl2.bias.data:
        writefile.write(str(layer.item()) + ",")
        
  def exportWeights(self):
    with open("weights.dat", "w") as writefile:
      writefile.write("Input weights\n")
      for layer in self.inputLayer.weight.data:
        for neuron in layer:
          writefile.write(str(neuron.item()) + ",")
        writefile.write("\t")
      writefile.write("\nFirst Hidden\n")
      for layer in self.hl1.weight.data:
        for neuron in layer:
          writefile.write(str(neuron.item()) + ",")
        writefile.write("\t")
      writefile.write("Second Hidden\n")
      for layer in self.hl2.weight.data:
        for neuron in layer:
          writefile.write(str(neuron.item()) + ",")
        writefile.write("\t")
      
  def exportModel(self):
    f = open("model.networkmodel", "wb")
    pickle.dump(self, f)
    f.close()
  
  def loadModel(self):
    f = open("model.networkmodel", "rb")
    self = pickle.load(f)
    f.close()

model = NeuralNet()
model.exportBiases()
model.exportWeights()
model.exportModel()
summary(model, input_size=(1, 13, 13))

# specify loss function
criterion = nn.CrossEntropyLoss()

# specify optimizer
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# number of epochs to train the model
n_epochs = 50  # suggest training between 20-50 epochs

# Set model to the training mode
model.train()

for epoch in range(n_epochs):
    # monitor training loss
    train_loss = 0.0
    
    ###################
    # train the model #
    ###################
    for data, target in train_loader:
        # clear the gradients of all optimized variables
        optimizer.zero_grad()
        # forward pass: compute predicted outputs by passing inputs to the model
        output = model(data)

        # calculate the loss
        loss = criterion(output, target)
        # backward pass: compute gradient of the loss with respect to model parameters
        loss.backward()
        # perform a single optimization step (parameter update)
        optimizer.step()
        # update running training loss
        train_loss += loss.item()*data.size(0)
        
    # print training statistics 
    # calculate average loss over an epoch
    train_loss = train_loss/len(train_loader.dataset)

    print('Epoch: {} \tTraining Loss: {:.6f}'.format(
        epoch+1, 
        train_loss
        ))

# initialize lists to monitor test loss and accuracy
test_loss = 0.0
class_correct = list(0. for i in range(10))
class_total = list(0. for i in range(10))

# Set model to evaluation mode
model.eval()

for data, target in test_loader:
    # forward pass: compute predicted outputs by passing inputs to the model
    output = model(data)
    # calculate the loss
    loss = criterion(output, target)
    # update test loss 
    test_loss += loss.item()*data.size(0)
    # convert output probabilities to predicted class
    _, pred = torch.max(output, 1)
    # compare predictions to true label
    correct = np.squeeze(pred.eq(target.data.view_as(pred)))
    # calculate test accuracy for each object class
    for i in range(batch_size):
        try:
          label = target.data[i]
          class_correct[label] += correct[i].item()
          class_total[label] += 1
        except IndexError:
          break

# calculate and print avg test loss
test_loss = test_loss/len(test_loader.dataset)
print('Test Loss: {:.6f}\n'.format(test_loss))

for i in range(10):
    if class_total[i] > 0:
        print('Test Accuracy of %5s: %2d%% (%2d/%2d)' % (
            str(i), 100 * class_correct[i] / class_total[i],
            np.sum(class_correct[i]), np.sum(class_total[i])))
    else:
        print('Test Accuracy of %5s: N/A (no training examples)' % (classes[i]))

print('\nTest Accuracy (Overall): %2d%% (%2d/%2d)' % (
    100. * np.sum(class_correct) / np.sum(class_total),
    np.sum(class_correct), np.sum(class_total)))

# obtain one batch of test images
dataiter = iter(test_loader)
images, labels = dataiter.next()

# get sample outputs
output = model(images)
# convert output probabilities to predicted class
_, preds = torch.max(output, 1)
# prep images for display
images = images.numpy()

# plot the images in the batch, along with predicted and true labels
fig = plt.figure(figsize=(25, 4))
for idx in np.arange(batch_size):
    ax = fig.add_subplot(2, int(batch_size/2), int(idx+1), xticks=[], yticks=[])
    ax.imshow(np.squeeze(images[idx]), cmap='gray')
    ax.set_title("{} ({})".format(str(preds[idx].item()), str(labels[idx].item())),
                 color=("green" if preds[idx]==labels[idx] else "red"))

model.exportBiases()
model.exportWeights()
model.exportModel()